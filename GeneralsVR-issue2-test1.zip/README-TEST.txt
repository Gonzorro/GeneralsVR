GeneralsVR test build for GitHub issue #2
=========================================

What this is: the same game as v0.1.4-alpha plus a safeguard around the VR
session start, which is the exact point where your crash happens (inside
Meta's runtime file RuntimeIPCServiceClient_32.dll). With this build the
game should survive that point. If Meta's runtime still refuses to start
the VR session, the game keeps running flat on your desktop and writes a
detailed log of what the runtime did.

How to install:
1. Close the game if it is running.
2. Open this folder in Explorer: %LOCALAPPDATA%\GeneralsVR
   (paste that path into the Explorer address bar and press Enter)
3. Copy generalszhv.exe from this zip into that folder, replacing the old one.
4. Start the game from your GeneralsVR desktop shortcut like always.

What I need back in the GitHub issue:
- Does it still crash, or does it now stay running (flat or VR)?
- Either way, attach the new DebugLogFile.txt from %LOCALAPPDATA%\GeneralsVR.
  The new log tells me exactly what Meta's runtime did at the failure point.

To go back to the normal version: the launcher restores the official build
if you press V and reinstall, or just wait for the next release which will
include this fix.

Thanks for helping me test this!
